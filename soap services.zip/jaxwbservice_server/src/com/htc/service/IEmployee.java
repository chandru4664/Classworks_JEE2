package com.htc.service;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.htc.model.Employee;

@WebService
public interface IEmployee {
	@WebMethod
	public Employee getEmployee(int eid) ;
}
