package com.htc.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.jws.WebService;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.ctc.wstx.api.EmptyElementHandler;
import com.htc.model.Employee;

@WebService(endpointInterface="com.htc.service.IEmployee")

public class EmployeeImpl implements IEmployee {


	public Employee getEmployee(int eid) 
	{
		Employee e=null;
		Connection con = null;
		try
		{
			InitialContext ctx=new InitialContext();
			DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/user");
			 con=ds.getConnection();
			 
			PreparedStatement ps=con.prepareStatement("select empid,empname,salary,job from employee where empid=?");
			ps.setInt(1, eid);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				int id=rs.getInt(1);
				String ename=rs.getString(2);
				double salary=rs.getDouble(3);
				
				String job=rs.getString(4);
				 e=new Employee(id,ename,salary,job);
			}
			
			
		}
		catch(SQLException se )
		{
			se.printStackTrace();
		} catch (NamingException ee) {
			// TODO Auto-generated catch block
			ee.printStackTrace();
		}
	
		
		
		return e;
		
	}

}
