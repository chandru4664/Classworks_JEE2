package com.htc.main;

import javax.xml.ws.Endpoint;

import com.htc.ws.EmployeeserviceImpl;

public class PublishService {
	public static void main(String[] args) {

		try {
			Endpoint.publish("http://localhost:4525/service/Myservice", new EmployeeserviceImpl());
			System.out.println("Done");
		} catch (Exception ex) {
			System.out.println(ex.getMessage());

		}
	}
}
