package com.htc.ws;

import javax.jws.WebService;

@WebService(endpointInterface="com.htc.ws.Employeeservice")
public class EmployeeserviceImpl implements Employeeservice {

	@Override
	public String greetMsg(String name) {
		// TODO Auto-generated method stub
		return "HI "+name;
	}

	@Override
	public double calc(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}

}
