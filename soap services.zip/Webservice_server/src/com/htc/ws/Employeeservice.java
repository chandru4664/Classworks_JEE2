package com.htc.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface Employeeservice {

	@WebMethod
	public String greetMsg(String name);
	
	@WebMethod
	public double calc(int a,int b);
	
}
