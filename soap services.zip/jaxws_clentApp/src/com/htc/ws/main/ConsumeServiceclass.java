package com.htc.ws.main;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import com.htc.ws.Employeeservice;
import com.htc.ws.EmployeeserviceImplService;
import com.htc.ws.EmployeeserviceImplServiceLocator;

public class ConsumeServiceclass {

	public static void main(String[] args) throws RemoteException {
		EmployeeserviceImplService service=new EmployeeserviceImplServiceLocator();
		try {
			Employeeservice employee=service.getEmployeeserviceImplPort();
			System.out.println(employee.greetMsg("Vinod"));
			System.out.println(employee.calc(45, 12));
			
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
