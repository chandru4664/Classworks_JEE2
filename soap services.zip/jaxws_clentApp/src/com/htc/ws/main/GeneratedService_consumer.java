package com.htc.ws.main;

import com.htc.generatedService.Employeeservice;
import com.htc.generatedService.EmployeeserviceImplService;

public class GeneratedService_consumer {
public static void main(String[] args) {
	EmployeeserviceImplService service=new EmployeeserviceImplService();
	 Employeeservice emp=service.getEmployeeserviceImplPort();
	 System.out.println(emp.calc(45, 89));
}
}
