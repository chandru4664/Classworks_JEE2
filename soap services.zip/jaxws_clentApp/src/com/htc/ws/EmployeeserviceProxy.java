package com.htc.ws;

public class EmployeeserviceProxy implements com.htc.ws.Employeeservice {
  private String _endpoint = null;
  private com.htc.ws.Employeeservice employeeservice = null;
  
  public EmployeeserviceProxy() {
    _initEmployeeserviceProxy();
  }
  
  public EmployeeserviceProxy(String endpoint) {
    _endpoint = endpoint;
    _initEmployeeserviceProxy();
  }
  
  private void _initEmployeeserviceProxy() {
    try {
      employeeservice = (new com.htc.ws.EmployeeserviceImplServiceLocator()).getEmployeeserviceImplPort();
      if (employeeservice != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)employeeservice)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)employeeservice)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (employeeservice != null)
      ((javax.xml.rpc.Stub)employeeservice)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.htc.ws.Employeeservice getEmployeeservice() {
    if (employeeservice == null)
      _initEmployeeserviceProxy();
    return employeeservice;
  }
  
  public java.lang.String greetMsg(java.lang.String arg0) throws java.rmi.RemoteException{
    if (employeeservice == null)
      _initEmployeeserviceProxy();
    return employeeservice.greetMsg(arg0);
  }
  
  public double calc(int arg0, int arg1) throws java.rmi.RemoteException{
    if (employeeservice == null)
      _initEmployeeserviceProxy();
    return employeeservice.calc(arg0, arg1);
  }
  
  
}