/**
 * Employeeservice.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.htc.ws;

public interface Employeeservice extends java.rmi.Remote {
    public java.lang.String greetMsg(java.lang.String arg0) throws java.rmi.RemoteException;
    public double calc(int arg0, int arg1) throws java.rmi.RemoteException;
}
