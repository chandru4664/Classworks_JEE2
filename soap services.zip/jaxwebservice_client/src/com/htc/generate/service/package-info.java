@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.htc.com/")
package com.htc.generate.service;
