package com.htc.springboot.security;

public interface UserSecurityDAO {

	public UserInfo findByssoId(String ssoId);
}
